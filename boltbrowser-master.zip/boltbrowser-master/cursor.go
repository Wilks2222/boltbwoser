package main

type Cursor struct {
	x int
	y int
}
